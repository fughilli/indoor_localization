/*
 * SPDX-FileCopyrightText: 2020-2026 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#pragma once

#include <stdint.h>
#include "esp_loader.h"

typedef struct target_registers_t {
    uint32_t cmd;
    uint32_t usr;
    uint32_t usr1;
    uint32_t usr2;
    uint32_t w0;
    uint32_t mosi_dlen;
    uint32_t miso_dlen;
} target_registers_t;

/**
 * @brief Detect the connected target chip and populate ctx->target and ctx->reg.
 *
 * If ctx->target is already set (e.g. SDIO identified the chip during card init),
 * only the register table is looked up and GET_SECURITY_INFO is skipped.
 * Otherwise the full UART/SPI detection sequence is used.
 */
// ESP32-P4 chip revision v3.0 corresponds to ECO5; earlier silicon needs the rev1 stub.
#define ESP32P4_ECO_REV3_MIN 5

esp_loader_error_t loader_detect_chip(esp_loader_t *loader);
esp_loader_error_t loader_read_mac(esp_loader_t *loader, target_chip_t target_code, uint8_t *mac);

esp_loader_error_t loader_read_chip_revision(esp_loader_t *loader, target_chip_t target_code, uint16_t *revision);
bool encryption_in_begin_flash_cmd(target_chip_t target);
esp_loader_error_t loader_read_spi_config(esp_loader_t *loader, target_chip_t target_chip, uint32_t *spi_config);
target_chip_t target_from_chip_id(uint32_t chip_id);
const target_registers_t *get_esp_target_data(target_chip_t chip);
uint32_t esp_targets_get_efuse_base(target_chip_t target);
esp_loader_error_t get_crystal_frequency_esp32c2(esp_loader_t *loader, uint32_t *frequency);

/**
 * @brief Power on the SPI flash of an ESP32-P4 v3.1+ before it is accessed from ROM or stub.
 *
 * Same sequence as esptool's ESP32P4ROM.power_on_flash(), also applied to revisions above v3.2,
 * whose ROM can safely re-run its own power-on. Not usable in secure download mode.
 */
esp_loader_error_t loader_power_on_flash_esp32p4(esp_loader_t *loader);
